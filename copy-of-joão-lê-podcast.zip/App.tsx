
import React, { useEffect } from 'react';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Subscribe } from './components/Subscribe';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  useEffect(() => {
    const observerOptions = {
      threshold: 0.15,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.reveal');
    revealElements.forEach((el) => observer.observe(el));

    return () => {
      revealElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen relative flex flex-col">
      <div className="fixed inset-0 retro-grid opacity-20 pointer-events-none"></div>
      
      <Header />
      
      <main className="flex-grow">
        <section id="hero">
          <Hero />
        </section>
        
        <section id="about" className="py-20 bg-black/40">
          <About />
        </section>
        
        <section id="subscribe" className="py-20 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500"></div>
          <Subscribe />
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default App;
