
import React from 'react';
import { Newspaper, MessageSquare, Music } from 'lucide-react';

export const About: React.FC = () => {
  const features = [
    {
      icon: <Newspaper className="text-pink-500" size={40} />,
      title: "NOTÍCIAS INÚTEIS",
      desc: "Por que falar de política quando podemos discutir o formato das novas tampas de garrafa?",
      reveal: "reveal-left"
    },
    {
      icon: <MessageSquare className="text-cyan-400" size={40} />,
      title: "CONVERSA FIADA",
      desc: "João Lê domina a arte de falar por 45 minutos sem chegar a conclusão nenhuma. É hipnotizante.",
      reveal: "reveal-bottom"
    },
    {
      icon: <Music className="text-yellow-400" size={40} />,
      title: "VIBE ANALÓGICA",
      desc: "Sons sintetizados, chiado de fita e aquela estética que só o final do século XX poderia nos dar.",
      reveal: "reveal-right"
    }
  ];

  return (
    <div className="container mx-auto px-6">
      <div className="text-center mb-16 reveal reveal-bottom">
        <h2 className="text-4xl md:text-6xl mb-4 neon-text">SOBRE O SHOW</h2>
        <div className="h-1 w-24 bg-pink-500 mx-auto"></div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {features.map((f, i) => (
          <div key={i} className={`bg-white/5 border border-white/10 p-8 hover:border-pink-500/50 transition-all group hover:-translate-y-2 reveal ${f.reveal}`}>
            <div className="mb-6 group-hover:scale-110 transition-transform">{f.icon}</div>
            <h3 className="text-xl font-retro mb-4 text-white group-hover:text-pink-400 transition-colors">{f.title}</h3>
            <p className="text-gray-400 leading-relaxed font-light">
              {f.desc}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-20 p-8 md:p-12 border-2 border-dashed border-cyan-500/30 flex flex-col md:flex-row items-center gap-10 reveal reveal-bottom">
        <div className="text-7xl opacity-20 font-retro rotate-90 md:rotate-0">?</div>
        <div className="flex-1">
          <p className="text-xl md:text-2xl font-light italic text-gray-300">
            "Eu acredito que as coisas mais importantes são as que ninguém presta atenção. Se você quer saber sobre o futuro, olhe para os detalhes que estão sendo descartados no lixo."
          </p>
          <p className="mt-4 font-pixel text-sm text-cyan-400">— João Lê, Episódio #042</p>
        </div>
      </div>
    </div>
  );
};
