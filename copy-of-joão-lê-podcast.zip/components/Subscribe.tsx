
import React, { useState } from 'react';
import { Send, CheckCircle2 } from 'lucide-react';

export const Subscribe: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      // Simulate API call
      setTimeout(() => {
        setSubmitted(false);
        setEmail('');
      }, 5000);
    }
  };

  return (
    <div className="container mx-auto px-6 max-w-4xl text-center">
      <div className="relative inline-block mb-12 reveal reveal-left">
        <h2 className="text-4xl md:text-6xl neon-text">NÃO PERCA O <span className="text-yellow-400">BEAT</span></h2>
        <div className="absolute -top-6 -right-12 bg-pink-600 px-3 py-1 font-pixel text-[10px] transform rotate-12">NEWSLETTER</div>
      </div>
      
      <p className="text-lg text-gray-400 mb-10 max-w-2xl mx-auto reveal reveal-right">
        Deixe seu contato e enviaremos um bip (ou um e-mail) sempre que João Lê decidir que tem algo não importante para dizer.
      </p>

      <div className="reveal reveal-bottom">
        {submitted ? (
          <div className="bg-cyan-500/20 border-2 border-cyan-500 p-10 flex flex-col items-center animate-bounce">
            <CheckCircle2 size={48} className="text-cyan-400 mb-4" />
            <h3 className="text-2xl font-retro text-white">SINTONIZADO COM SUCESSO!</h3>
            <p className="font-pixel text-[10px] mt-2">VERIFIQUE SUA CAIXA DE ENTRADA</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="relative group">
            <div className="flex flex-col md:flex-row gap-0">
              <input 
                type="email" 
                placeholder="SEU.EMAIL@PRODIGY.NET"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 bg-black/60 border-2 border-white/20 px-6 py-5 text-xl font-light text-cyan-400 focus:outline-none focus:border-cyan-500 transition-all placeholder:text-white/20"
              />
              <button 
                type="submit"
                className="bg-yellow-400 hover:bg-yellow-300 text-black px-10 py-5 font-retro flex items-center justify-center gap-3 transition-all active:scale-95"
              >
                INSCREVER <Send size={20} />
              </button>
            </div>
            {/* Decorative bits */}
            <div className="absolute -bottom-3 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>
          </form>
        )}
      </div>

      <div className="mt-12 flex justify-center gap-6 grayscale opacity-50 reveal reveal-bottom">
        <div className="text-[10px] font-pixel">EST. 1984</div>
        <div className="text-[10px] font-pixel">•</div>
        <div className="text-[10px] font-pixel">SÃO PAULO - BRAZIL</div>
        <div className="text-[10px] font-pixel">•</div>
        <div className="text-[10px] font-pixel">BROADCASTING WORLDWIDE</div>
      </div>
    </div>
  );
};
