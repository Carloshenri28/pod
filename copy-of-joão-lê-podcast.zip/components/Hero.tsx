
import React, { useEffect, useState } from 'react';
import { PlayCircle, CassetteTape } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const Hero: React.FC = () => {
  const [characterImage, setCharacterImage] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateCharacter = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                text: 'A professional 80s synthwave illustration of João Lê. He is a stylish Black man with a large perfectly rounded Afro (Black Power), wearing cool retro 80s sunglasses and laughing heartily with a big smile. He wears a minimalist 80s outfit. Background is dark purple with a retro neon grid and a vibrant stylized synthwave sunset. Vibrant neon accents, high quality digital art style, aesthetic 80s vibes, joyful expression.',
              },
            ],
          },
        });

        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            setCharacterImage(`data:image/png;base64,${part.inlineData.data}`);
          }
        }
      } catch (error) {
        console.error("Error generating character:", error);
        // Fallback placeholder with 80s style if generation fails
        setCharacterImage('https://picsum.photos/seed/joaole/800/800');
      } finally {
        setLoading(false);
      }
    };

    generateCharacter();
  }, []);

  return (
    <div className="relative min-h-[90vh] flex flex-col md:flex-row items-center justify-center px-6 md:px-20 py-10 gap-12 overflow-hidden">
      {/* Decorative Memphis shapes */}
      <div className="absolute top-20 right-10 w-20 h-20 border-4 border-yellow-400 rotate-45 opacity-50 hidden lg:block"></div>
      <div className="absolute bottom-40 left-10 w-32 h-4 bg-cyan-500 -rotate-12 opacity-50 hidden lg:block"></div>
      
      <div className="flex-1 text-center md:text-left z-10 reveal reveal-left active">
        <p className="font-pixel text-cyan-400 mb-4 animate-pulse uppercase tracking-[0.2em]">Sintonize na Frequência</p>
        <h2 className="text-5xl md:text-8xl mb-6 leading-tight italic">
          CONVERSA <br /> 
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-yellow-500">FORA</span>
        </h2>
        <p className="text-lg md:text-xl text-gray-300 max-w-xl mb-10 leading-relaxed font-light">
          Apenas João Lê jogando conversa fora sobre as notícias mais irrelevantes do mundo. Se não importa, a gente discute.
        </p>
        
        <div className="flex flex-wrap gap-4 justify-center md:justify-start">
          <button className="flex items-center gap-2 bg-pink-600 hover:bg-pink-500 text-white px-8 py-4 rounded-none font-retro transform hover:scale-105 transition-all neon-border">
            <PlayCircle size={24} />
            OUVIR AGORA
          </button>
          <button className="flex items-center gap-2 border-2 border-cyan-500 text-cyan-500 hover:bg-cyan-500/10 px-8 py-4 rounded-none font-retro transition-all">
            <CassetteTape size={24} />
            EPISÓDIOS
          </button>
        </div>
      </div>

      <div className="flex-1 relative z-10 w-full max-w-md md:max-w-xl reveal reveal-right active">
        <div className="relative aspect-square">
          <div className="absolute inset-0 bg-pink-500/20 rounded-full blur-3xl animate-pulse"></div>
          {loading ? (
            <div className="w-full h-full flex items-center justify-center bg-black/40 border-4 border-dashed border-pink-500">
               <span className="font-pixel text-xs text-pink-500">CARREGANDO JOÃO LÊ...</span>
            </div>
          ) : (
            <div className="relative group">
               <img 
                src={characterImage} 
                alt="João Lê" 
                className="w-full h-full object-cover grayscale-0 group-hover:contrast-125 transition-all duration-500 border-4 border-cyan-400 p-2 bg-black"
              />
              <div className="absolute -bottom-6 -right-6 font-pixel bg-yellow-400 text-black px-4 py-2 transform rotate-3">
                ORIGINAL 1984
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
