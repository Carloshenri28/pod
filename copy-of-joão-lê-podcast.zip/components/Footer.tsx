
import React from 'react';
import { Instagram, Twitter, Youtube, Github } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-12 px-6 border-t border-white/10">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <h3 className="text-xl font-retro neon-text mb-2">JOÃO LÊ</h3>
          <p className="text-xs font-pixel text-gray-500 uppercase tracking-widest">Copyright © 1984 - 2024</p>
        </div>

        <div className="flex gap-6">
          <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-pink-500 transition-all hover:text-white text-pink-500">
            <Instagram size={20} />
          </a>
          <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-cyan-500 transition-all hover:text-white text-cyan-500">
            <Twitter size={20} />
          </a>
          <a href="#" className="p-3 bg-white/5 rounded-full hover:bg-yellow-500 transition-all hover:text-black text-yellow-500">
            <Youtube size={20} />
          </a>
        </div>

        <div className="text-right">
          <p className="text-xs font-pixel text-gray-600">DESIGN BY VAPORWAVE CORP</p>
          <div className="flex justify-end gap-1 mt-2">
            <div className="w-4 h-4 bg-pink-500"></div>
            <div className="w-4 h-4 bg-purple-600"></div>
            <div className="w-4 h-4 bg-cyan-500"></div>
            <div className="w-4 h-4 bg-yellow-400"></div>
          </div>
        </div>
      </div>
    </footer>
  );
};
