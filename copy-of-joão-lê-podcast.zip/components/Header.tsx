
import React from 'react';
import { Radio } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-40 bg-black/80 backdrop-blur-md border-b-2 border-pink-500 py-4 px-6 md:px-12 flex justify-between items-center">
      <div className="flex items-center gap-3">
        <Radio className="text-cyan-400 animate-pulse" size={32} />
        <h1 className="text-xl md:text-2xl tracking-tighter text-white neon-text">
          JOÃO LÊ <span className="text-pink-500">PODCAST</span>
        </h1>
      </div>
      
      <nav className="hidden md:flex gap-8 font-pixel text-xs">
        <a href="#hero" className="hover:text-cyan-400 transition-colors uppercase">Início</a>
        <a href="#about" className="hover:text-pink-400 transition-colors uppercase">O Show</a>
        <a href="#subscribe" className="hover:text-yellow-400 transition-colors uppercase">Notificações</a>
      </nav>

      <div className="text-[10px] font-pixel bg-pink-600 px-2 py-1 rounded animate-bounce">
        LIVE NOW
      </div>
    </header>
  );
};
